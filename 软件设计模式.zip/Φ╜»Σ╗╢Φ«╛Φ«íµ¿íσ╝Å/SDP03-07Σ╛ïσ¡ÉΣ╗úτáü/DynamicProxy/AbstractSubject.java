public interface AbstractSubject
{
	public void request();
}