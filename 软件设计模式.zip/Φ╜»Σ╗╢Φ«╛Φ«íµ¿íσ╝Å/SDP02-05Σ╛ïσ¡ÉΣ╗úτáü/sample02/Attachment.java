import java.io.*;

public class Attachment implements Serializable
{
    public void download()
    {
    	System.out.println("���ظ���");	
    }
}