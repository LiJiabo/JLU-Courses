public class Transfer extends BankTemplateMethod
{
	public void transact()
	{
		System.out.println("ת��");		
	}
}