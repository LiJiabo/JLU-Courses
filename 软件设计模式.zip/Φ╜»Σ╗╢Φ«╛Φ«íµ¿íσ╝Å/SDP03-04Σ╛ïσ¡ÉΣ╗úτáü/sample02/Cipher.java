public interface Cipher
{
	public String encrypt(String plainText);
}
