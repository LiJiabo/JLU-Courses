public abstract class MyElement
{
	public abstract void eat();
}