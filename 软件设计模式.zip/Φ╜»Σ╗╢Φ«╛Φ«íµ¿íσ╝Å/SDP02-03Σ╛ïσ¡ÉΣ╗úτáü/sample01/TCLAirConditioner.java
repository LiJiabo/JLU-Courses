public class TCLAirConditioner implements AirConditioner
{
	public void changeTemperature()
	{
		System.out.println("TCL�յ��¶ȸı���......");
	}
}